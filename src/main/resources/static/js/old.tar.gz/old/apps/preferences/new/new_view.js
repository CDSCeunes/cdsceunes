define(["app.js"], function("CDSCeunes") {
	CDSCeunes.module("PreferencesApp.View", View, CDSCeunes, Backbone, Marionette, $, _) {
		
	}
});