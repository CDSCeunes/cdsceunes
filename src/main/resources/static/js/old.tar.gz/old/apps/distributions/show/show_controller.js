define(["app"], function(CDSCeunes) {
  CDSCeunes.module("DistributionsApp.ShowController", function(Show, CDSCeunes, Backbone, Marionette, $, _) {
    Show.Controller = {
      showController: function(id) {
      }
    }
  });
});
