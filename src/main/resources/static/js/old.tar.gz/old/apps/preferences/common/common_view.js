define(["app"], function(CDSCeunes) {
	CDSCeunes.module("PreferencesApp.View", View, CDSCeunes, Backbone, Marionette, $, _) {
		View.Form =  // TODO
	
	}

	return CDSCeunes.PreferencesApp.View;
});